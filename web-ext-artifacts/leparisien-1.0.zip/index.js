document.querySelectorAll('section.content').forEach((el) => el.style.filter='none');
document.querySelector('[id^=offer-]').style.display='none';
